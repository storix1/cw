pip install colorama selenium mechanize pygoogling
easy_install hashlib

# optparse, smtplib and platform  modules are already installed in pyhton2.7
# by default so it will be there when you install(update) python2
